# How to run the following Lead-Counseller Matching System


## Prereqs

1. Install python
2. Unzip the Lead-Counsellor Matching System code in a folder of your choice on your system. **Say folder X.**

## Install a virtual environment

1. Open a command prompt in the folder X, that is the folder in which you have the Lead-Counsellor Matching system code.
2. Run the following commands in the given sequence in folder X:
   1. Open a command window in folder X
   2. python -m venv venv
   3. venv\Scripts\activate
   4. pip install -r requirements.txt
   5. python -m spacy download en_core_web_sm


## Run the Application

Execute the following steps:

1. Open a command window in folder X
2. venv\Scripts\activate
3. streamlit run app.py

These commands should openup the user interface on your default web browser. 

You can alternatively access the application by typing: localhost:8501 in your browser.


## How to use the application to demo?

### The frontpage of the application

![1730089259721](image/ReadMe/1730089259721.png)

### Upload the Leads, Counsellors, and the Rules

Upload the files as shown in the snapshot below from the folder X/dataset

![1730089656254](image/ReadMe/1730089656254.png)


### Click on the "Run Lead-Counsellor Matching Method" button as shown in the snapshot below.

![1730089975811](image/ReadMe/1730089975811.png)

### The result of clicking the button above looks as in the snaphot below

![1730090122387](image/ReadMe/1730090122387.png)
