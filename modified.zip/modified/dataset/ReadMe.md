# How to run the following Lead-Counseller Matching System


## Prereqs

1. Install python
2. Unzip the Lead-Counsellor Matching System code in a folder of your choice on your system. **Say folder X.**

## Install a virtual environment

1. Open a command prompt in the folder X, that is the folder in which you have the Lead-Counsellor Matching system code.
2. Run the following commands in the given sequence in folder X:
   1. Open a command window in folder X
   2. python -m venv venv
   3. venv\Scripts\activate
   4. pip install -r requirements.txt
   5. python -m spacy download en_core_web_sm


## Run the Application

Execute the following steps:

1. Open a command window in folder X
2. venv\Scripts\activate
3. streamlit run app.py

These commands should openup the user interface on your default web browser
