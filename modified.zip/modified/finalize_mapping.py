import pulp

import pulp

def allocate_leads(leads, counsellors, matching_scores, capacities):
    # Create the problem instance
    prob = pulp.LpProblem("Lead_Counsellor_Assignment", pulp.LpMaximize)

    # Decision variables using iterrows
    x = pulp.LpVariable.dicts(
        "assign",
        (
            (lead['id'], counsellor['id']) 
            for _, lead in leads.iterrows() 
            for _, counsellor in counsellors.iterrows()
        ),
        cat='Binary'
    )

    # Objective function
    prob += pulp.lpSum(
        matching_scores[(lead['id'], counsellor['id'])] * x[(lead['id'], counsellor['id'])]
        for _, lead in leads.iterrows() 
        for _, counsellor in counsellors.iterrows()
    )

    # Constraints
    # Each lead is assigned to exactly one counsellor
    for _, lead in leads.iterrows():
        prob += pulp.lpSum(
            x[(lead['id'], counsellor['id'])] for _, counsellor in counsellors.iterrows()
        ) == 1

    # Counsellor capacity constraints
    for _, counsellor in counsellors.iterrows():
        prob += pulp.lpSum(
            x[(lead['id'], counsellor['id'])] for _, lead in leads.iterrows()
        ) <= capacities[counsellor['id']]

    # Solve the problem
    prob.solve()

    # Extract the results
    assignment = {}
    for _, lead in leads.iterrows():
        for _, counsellor in counsellors.iterrows():
            if pulp.value(x[(lead['id'], counsellor['id'])]) == 1:
                assignment[lead['id']] = counsellor['id']

    return assignment

def matching_scores_dictionary(matched_df):
    matching_scores = {}
    for index, row in matched_df.iterrows():
        lead_id = row['Lead ID']
        counsellor_id = row['Counsellor ID']
        score = row['Matching Score']
        matching_scores[(lead_id, counsellor_id)] = score
    return matching_scores

def capacities_dictionary(counsellors_df):
    print(counsellors_df.columns)
    capacities = {}
    for index, row in counsellors_df.iterrows():
        print("################################### capacity")
        #print(counsellor)
        #print(counsellor.id)
        capacities[row['id']] = row['Capacity']  # Ensure 'Capacity' attribute exists
    return capacities